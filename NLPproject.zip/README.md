# word2vec
- install python lib
  type -> yarn
  or type -> npm install

-------------------------
- install python lib

    !pip install flask flask_bootstrap pandas nltk transformers sklearn pickle

-------------------------

- install stopwords type underline word in python complier

    nltk.download('stopwords')

